we have developed our program on jupyter notebook which is python based notebook.
To run the program:

1.Load the source file in the jupyter notebook
2.Install all the required libraries in in the jupyter notebook.
 ex: !pip install tensorflow
3.In the second cell of the source code set the path to your tarining data set.
4.then goto Cell>Run all cells

5.Assuming all libraries are installed the code will run and give the output shown in the 